import sqlite3

def get_connection(database):
	try:
		conn = sqlite3.connect(database)

	except Exception as e:
		print(e)
		conn =  None
	return conn

def create_tables(database):
	conn = get_connection(database)
	students_create_query='''
	CREATE TABLE IF NOT EXISTS STUDENTS(ID INTEGER PRIMARY KEY,
										NAME VARCHAR(50) NOT NULL,
										ADHAR INTEGER NOT NULL,
										PHONE INTEGER NOT NULL,
										EMAIL VARCHAR(30) NOT NULL,
										PASSWORD VARCHAR(20) NOT NULL)
						  '''

	if conn is not None:
		conn.execute(students_create_query)
		conn.commit()
		conn.close()

	conn = get_connection(database)
	queries_create_query='''
	CREATE TABLE IF NOT EXISTS QUERIES(ID INTEGER PRIMARY KEY,
										EMAIL VARCHAR(50) NOT NULL,
										UNAME VARCHAR(30) NOT NULL,
										QUERY VARCHAR(100) NOT NULL)
						  '''

	if conn is not None:
		conn.execute(queries_create_query)
		conn.commit()
		conn.close()

	return 'SUCCESS'

def add_user(name,adhar,phone,email,password):
	print(create_tables("janajagrut.db"))
	add_student_query =''' 
	  INSERT INTO STUDENTS(name,adhar,phone,email,password) values(?,?,?,?,?)
	                   '''
	conn = get_connection("janajagrut.db")
	if conn is not None:
		try:
			conn.execute(add_student_query,(name,adhar,phone,email,password))
			conn.commit()
			status = "SUCCESS"

		except Exception as e:
			print(e)
			status = "FAILURE"

		finally:
			conn.close()

	return status

def add_query(email,uname,query):
	print(create_tables("janajagrut.db"))
	add_queries_query =''' 
	  INSERT INTO QUERIES(email,uname,query) values(?,?,?)
	                   '''
	conn = get_connection("janajagrut.db")
	if conn is not None:
		try:
			conn.execute(add_queries_query,(email,uname,query))
			conn.commit()
			status = "SUCCESS"

		except Exception as e:
			print(e)
			status = "FAILURE"

		finally:
			conn.close()

	return status

def verify(name):
	print(name)
	query='''
	SELECT PASSWORD FROM STUDENTS
	WHERE NAME = ?
	'''

	conn = get_connection("janajagrut.db")
	c = conn.cursor()

	if conn is  not None:
		try:
			c.execute(query,(name,))
			pwd = c.fetchone()
		except Exception as e:
			print(e)
			pwd=''

		finally:
			conn.close()
	print(pwd[0])
	return pwd[0]

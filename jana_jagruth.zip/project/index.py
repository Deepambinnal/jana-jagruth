from flask import Flask, escape, request, render_template,redirect,session,url_for
import sql as db

app=Flask(__name__)

@app.route('/')
def hello():
    
    return render_template('index.html', title='Jana Jagruth')

@app.route('/about')
def about():
    """Renders the about page."""
    return render_template(
        'home.html',
        title='About',
        year=2020,
        message='Your application description page.'
    )
@app.route('/login')
def login():
	return render_template('login.html')

@app.route('/signup')
def signup():
	return render_template('signup.html')

@app.route('/logout')
def logout():
	return render_template('index.html',title='Jana Jagruth')


@app.route("/add_user", methods=['POST'])
def add_user():
	name = request.form['name']
	adhar = request.form['adhar']
	phone = request.form['phone']
	email = request.form['email']
	password = request.form['pass']
	status = db.add_user(name,adhar,phone,email,password)
	return redirect(url_for('feed',msg=status))

@app.route("/feed")
def feed():
	return render_template('home.html')

@app.route("/userLogin",methods=['GET','POST'])
def studentLogin():
	if request.method == 'GET':
		return render_template("index.html")
	else:
		name = request.form.get('name')
		password = request.form.get('password')
		print(password,name)
		pwd=db.verify(name)
		if password == pwd:
			return redirect(url_for("feed",msg="Login successful"))
		else:
			return redirect(url_for('login',msg="Wrong credentials"))

@app.route("/QuerySubmit",methods=['POST'])
def QuerySubmit():
	email=request.form.get('email')
	uname=request.form.get('uname')
	query=request.form.get('query')
	status = db.add_query(email,uname,query)
	print(status)
	return redirect(url_for('feed',msg=status))

if __name__ == '__main__':
	app.run(debug=True)